def main():
    print("Hello")
